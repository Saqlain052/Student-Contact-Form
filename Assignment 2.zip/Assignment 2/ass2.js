function textChange() {
    document.querySelector(".home").innerHTML = "HTML: Structure of a webpage. <br> CSS: Styling of a webpage.<br> JavaScript: Interactivity of a webpage";
}


function formValidation (){
let lname = document.getElementById("name").value.trim();
let email= document.getElementById("email").value.trim();
let message= document.getElementById("message");

let isValid= true;

if(lname===""){
    alert("Name Required for Submission");
    document.getElementById("name").style.border="2px solid red";
    isValid=false;
}
if(email===""){
    alert("Email Required for Submission");
    document.getElementById("email").style.border="2px solid red";
    isValid=false;
}
else if(!email.includes("@") || !email.includes(".")){
    alert("Invalid Email Format");
    document.getElementById("email").style.border="2px solid red";
    isValid=false;
}
if(isValid){
message.innerText="Form Submit Successfully";
}
return false;
}